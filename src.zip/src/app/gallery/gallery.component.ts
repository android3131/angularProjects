import { Component } from '@angular/core';
import { Person } from '../types';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent {

  peopleArr: Person[] = [
    {
      name: { first: "John", last: "Doe" },
      birthYear: 2003,
      favorite: false
    },
    {
      name: { first: "Kate", last: "Klein" },
      birthYear: 2005,
      favorite: false
    }
  ]


  handleFavoriteToggled(person: Person) {
    console.log('Favorite clicked for:',
      `${person.name.first} ${person.name.last}` +
      ` ,he is now ${person.favorite ? "favorite" : "NOT favorite"}`);
    // Handle favoriteToggled event here
  }
}
