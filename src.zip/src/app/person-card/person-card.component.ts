// personCard.component.ts
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Person } from '../types';

@Component({
  selector: 'app-person-card',
  templateUrl: './person-card.component.html',
  styleUrls: ['./person-card.component.css']
})
export class PersonCardComponent {
  @Input() thePersonOfTheCard?: Person;
  @Output() favoriteToggled = new EventEmitter<Person>();

  // usually we would just pass the id, but just to demo that we
  //   can pass an object lets pass a person object
  // person = {
  //   name: { first: "John", last: "Doe" },
  //   birthYear: 2003,
  //   favorite: false
  // };

  toggleFavorite() {
    this.thePersonOfTheCard!.favorite = !this.thePersonOfTheCard!.favorite;
    this.favoriteToggled.emit(this.thePersonOfTheCard);
  }
}
