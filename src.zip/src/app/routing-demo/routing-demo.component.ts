import { Component } from '@angular/core';

@Component({
  selector: 'app-routing-demo',
  templateUrl: './routing-demo.component.html',
  styleUrls: ['./routing-demo.component.css']
})
export class RoutingDemoComponent {

}
