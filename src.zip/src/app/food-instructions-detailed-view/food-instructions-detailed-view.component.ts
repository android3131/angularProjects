import { Component } from '@angular/core';

@Component({
  selector: 'app-food-instructions-detailed-view',
  templateUrl: './food-instructions-detailed-view.component.html',
  styleUrls: ['./food-instructions-detailed-view.component.css']
})
export class FoodInstructionsDetailedViewComponent {

}
