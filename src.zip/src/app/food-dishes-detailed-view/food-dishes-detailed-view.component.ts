import { Component } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { DataOfDishMealsFromAPI, MealDish } from '../types';
import { FoodService } from '../food.service';

@Component({
  selector: 'app-food-dishes-detailed-view',
  templateUrl: './food-dishes-detailed-view.component.html',
  styleUrls: ['./food-dishes-detailed-view.component.css']
})
export class FoodDishesDetailedViewComponent {
  categoryDihesId?: string;
  categoryDishesArr?: MealDish[];

  constructor(private route: ActivatedRoute, private foodService: FoodService) { }

  ngOnInit(): void {

    this.route.paramMap.subscribe((params: ParamMap) => {
      let temp = params.get('categoryId');
      this.categoryDihesId = temp ? temp : "NA";
      // console.log(`URL CHANGED TO ${temp} ${(new Date()).toLocaleString()}`);
      this.foodService.getMealDishesOfCategoryFromAPI(this.categoryDihesId);
    });

    // console.log(`subscribing to food data ${(new Date()).toLocaleString()}`);

    this.foodService.getTheMealDishesOfCategorySubject()
      .subscribe((dataOfDishMealsFromAPI) => {
        // console.log(`subscriber WAS CALLED ${(new Date()).toLocaleString()}`);
        this.categoryDishesArr = (dataOfDishMealsFromAPI as DataOfDishMealsFromAPI).meals;
      })

  }


}
